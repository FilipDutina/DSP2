#include "NoiseReduction.h"
#include "ImageFilter.h"
	
void performMovingAverage (uchar input[], int xSize, int ySize)
{
	//TO DO
}

void calculateGaussKernel(double kernel[], int N, double sigma)
{
	//TO DO
}

void performGaussFilter (uchar input[], int xSize, int ySize, double sigma)
{
	//TO DO
}

void performMedianFilter (uchar input[], int xSize, int ySize)
{
	//TO DO
}
