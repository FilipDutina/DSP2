
#include "InImgItem.h"
#include "ui_InImgItem.h"

InImgItem::InImgItem(QWidget* parent)
		: QWidget(parent), ui(new Ui_InImgItem) {
	ui->setupUi(this);

}
