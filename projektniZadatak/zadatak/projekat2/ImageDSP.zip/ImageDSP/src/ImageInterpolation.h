
#ifndef IMAGEINTERPOLATION_H_
#define IMAGEINTERPOLATION_H_

#include <QString>
#include <QVector>
#include <QImage>

void sampleAndHold(uchar input[], int xSize, int ySize, uchar output[], int newXSize, int newYSize);

void bilinearInterpolate(uchar input[], int xSize, int ySize, uchar output[], int newXSize, int newYSize);

void imageRotate(uchar input[], int xSize, int ySize, uchar output[], int m, int n, double angle);

void imageRotateBilinear(uchar input[], int xSize, int ySize, uchar output[], int m, int n, double angle);

#endif // IMAGEINTERPOLATION_H_
